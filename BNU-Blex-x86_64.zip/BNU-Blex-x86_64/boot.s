; ===========================================================================
; boot.s – BlexOS x86_64 entry point
; Multiboot2 header + 16→32→64 bit mode transition
;
; GRUB loads us in 32-bit protected mode (the Multiboot2 spec mandates this
; even for 64-bit kernels).  We therefore must:
;   1. Declare a Multiboot2 header so GRUB recognises the image.
;   2. Set up a minimal 64-bit GDT.
;   3. Build a tiny identity-map page table (4 GB, 2 MB huge pages).
;   4. Enable PAE + long mode + paging.
;   5. Far-jump into 64-bit code and call kernel_main(rdi=magic, rsi=mb2ptr).
;
; The Multiboot2 spec passes:
;   EAX = 0x36D76289   (magic)
;   EBX = physical address of the Multiboot2 information structure
; ===========================================================================

; ---------------------------------------------------------------------------
; Multiboot2 constants
; ---------------------------------------------------------------------------
MB2_MAGIC       equ 0xE85250D6
MB2_ARCH        equ 0                   ; i386 (always 0 for x86/x86_64)
MB2_HDR_LEN     equ (mb2_header_end - mb2_header_start)
MB2_CHECKSUM    equ -(MB2_MAGIC + MB2_ARCH + MB2_HDR_LEN)

; ---------------------------------------------------------------------------
; Multiboot2 header  (must be 64-byte aligned; placed in its own section so
; the linker can guarantee it lands within the first 32 KB of the image)
; ---------------------------------------------------------------------------
section .multiboot2
align 8
mb2_header_start:
    dd MB2_MAGIC
    dd MB2_ARCH
    dd MB2_HDR_LEN
    dd MB2_CHECKSUM

    ; ── Framebuffer tag (type 5) ────────────────────────
    align 8
    dw 5            ; type
    dw 0            ; flags
    dd 20           ; size
    dd 1920         ; preferred width
    dd 1080         ; preferred height
    dd 32           ; depth (bpp)

    ; ── End tag ─────────────────────────────────────────
    align 8
    dw 0
    dw 0
    dd 8
mb2_header_end:

; ---------------------------------------------------------------------------
; BSS – stack + page tables (must be in .bss so the image stays small)
; ---------------------------------------------------------------------------
section .bss
align 4096

; 64-bit page tables  (each table = 512 × 8-byte entries = 4 KB)
pml4_table:     resb 4096   ; PML4  – one entry → PDPT
pdpt_table:     resb 4096   ; PDPT  – one entry → PD
pd_table:       resb 4096   ; PD    – 512 huge-page (2 MB) entries = 1 GB

; 32 KB kernel stack
stack_bottom:
    resb 32768
stack_top:

; ---------------------------------------------------------------------------
; 32-bit protected-mode entry  (GRUB jumps here)
; ---------------------------------------------------------------------------
section .text
bits 32

global _start
extern kernel_main

_start:
    ; Save Multiboot2 arguments before we clobber registers
    mov edi, eax        ; mb2 magic  → will become first arg (rdi) later
    mov esi, ebx        ; mb2 info   → will become second arg (rsi) later

    ; Set up a sensible stack immediately
    mov esp, stack_top

    ; ── 1. Build identity-map page tables ───────────────
    ;
    ; PML4[0] → PDPT (present | writable)
    mov eax, pdpt_table
    or  eax, 0x03
    mov [pml4_table], eax

    ; PDPT[0] → PD   (present | writable)
    mov eax, pd_table
    or  eax, 0x03
    mov [pdpt_table], eax

    ; PD[0..511] → 2 MB huge pages  (present | writable | huge)
    ; Covers 0 – 1 GB physical, which is more than enough for the kernel.
    mov ecx, 0          ; loop counter / page index
.fill_pd:
    mov eax, 0x200000   ; 2 MB
    mul ecx             ; eax = index × 2 MB  (high 32 bits in edx, ignored)
    or  eax, 0x83       ; present | writable | PS (huge page)
    mov [pd_table + ecx*8], eax
    inc ecx
    cmp ecx, 512
    jne .fill_pd

    ; ── 2. Load PML4 into CR3 ────────────────────────────
    mov eax, pml4_table
    mov cr3, eax

    ; ── 3. Enable PAE (bit 5 of CR4) ─────────────────────
    mov eax, cr4
    or  eax, (1 << 5)
    mov cr4, eax

    ; ── 4. Set EFER.LME (bit 8 of MSR 0xC0000080) ───────
    mov ecx, 0xC0000080
    rdmsr
    or  eax, (1 << 8)
    wrmsr

    ; ── 5. Enable paging + protected mode (bits 31,0 of CR0) ──
    mov eax, cr0
    or  eax, (1 << 31) | (1 << 0)
    mov cr0, eax

    ; ── 6. Load 64-bit GDT and far-jump to 64-bit code ───
    lgdt [gdt64_desc]
    jmp  0x08:long_mode_entry   ; 0x08 = 64-bit code descriptor

; ---------------------------------------------------------------------------
; 64-bit code
; ---------------------------------------------------------------------------
bits 64
long_mode_entry:
    ; Set up 64-bit data/stack segment selectors
    mov ax, 0x10        ; data segment descriptor
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ; Zero-extend the 32-bit values saved in edi/esi into proper 64-bit regs.
    ; The SysV AMD64 ABI passes the first two arguments in rdi, rsi.
    mov edi, edi        ; zero-extend (mov r32,r32 always zero-extends to r64)
    mov esi, esi

    ; Call the C kernel
    call kernel_main

    ; Should never return – halt forever
.hang:
    cli
    hlt
    jmp .hang

; ---------------------------------------------------------------------------
; 64-bit GDT  (minimal: null + code64 + data64)
; ---------------------------------------------------------------------------
section .rodata
align 8
gdt64_start:
    ; 0x00 – null descriptor
    dq 0
    ; 0x08 – 64-bit code segment  (L=1, P=1, DPL=0, S=1, type=0xA exec/read)
    dw 0xFFFF           ; limit[15:0]
    dw 0x0000           ; base[15:0]
    db 0x00             ; base[23:16]
    db 0x9A             ; access: P=1 DPL=00 S=1 type=1010 (exec/read)
    db 0xAF             ; flags: G=1 D=0 L=1 AVL=0  + limit[19:16]=F
    db 0x00             ; base[31:24]
    ; 0x10 – 64-bit data segment  (type=0x2 read/write)
    dw 0xFFFF
    dw 0x0000
    db 0x00
    db 0x92             ; P=1 DPL=00 S=1 type=0010 (data read/write)
    db 0xCF
    db 0x00
gdt64_end:

gdt64_desc:
    dw (gdt64_end - gdt64_start - 1)   ; limit
    dq gdt64_start                      ; base (64-bit pointer)

; Mark stack as non-executable (suppresses linker warning)
section .note.GNU-stack noalloc noexec nowrite progbits

/*
 * initramfs.c – global state for the initramfs module
 *
 * initramfs.h contains the full implementation as static inline
 * functions for easy inclusion from any translation unit.
 * This file merely defines the one global variable that backs the
 * runtime state so it exists in exactly one object file.
 *
 * Copyright (C) 2026 Blex – BOSL License
 */

#include "initramfs.h"

/* One zero-initialised instance; populated by initramfs_load() */
initramfs_t g_initramfs = { .base = 0, .size = 0, .loaded = 0 };

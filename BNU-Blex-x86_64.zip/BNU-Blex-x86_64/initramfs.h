/*
 * initramfs.h – Real initramfs (CPIO newc) support for BlexOS x86_64
 *
 * This module replaces the old hardcoded uint32_t approach.
 * It uses proper 64-bit pointers throughout and provides:
 *
 *   initramfs_load(mb2_magic, mb2_info)
 *       – Scans the Multiboot2 info structure for module tags and
 *         registers the first CPIO archive found.
 *
 *   initramfs_find(path, out_size)
 *       – Locates a file inside the CPIO archive and returns a
 *         pointer to its data together with its size.
 *
 *   initramfs_foreach(cb, userdata)
 *       – Iterates every regular file in the archive, calling
 *         cb(path, data, size, userdata) for each one.
 *
 * CPIO newc format (magic "070701" / "070702"):
 *   Each entry = struct cpio_newc_header (110 bytes)
 *              + name  (namesize bytes, padded to 4-byte boundary)
 *              + data  (filesize bytes, padded to 4-byte boundary)
 *
 * Copyright (C) 2026 Blex – BOSL License
 */

#ifndef INITRAMFS_H
#define INITRAMFS_H

#include <stdint.h>

/* ── CPIO newc on-disk header (all fields ASCII hex, no NUL) ───── */
typedef struct __attribute__((packed)) {
    char magic[6];       /* "070701" or "070702"                    */
    char ino[8];         /* inode number                            */
    char mode[8];        /* file mode (octal encoded as hex string) */
    char uid[8];
    char gid[8];
    char nlink[8];
    char mtime[8];
    char filesize[8];    /* size of data section                    */
    char devmajor[8];
    char devminor[8];
    char rdevmajor[8];
    char rdevminor[8];
    char namesize[8];    /* length of filename, including NUL       */
    char check[8];       /* CRC (070702) or zero (070701)           */
} cpio_newc_hdr_t;       /* 110 bytes                               */

#define CPIO_NEWC_HDR_SIZE  110

/* ── Initramfs runtime state ─────────────────────────────────────── */
typedef struct {
    const uint8_t *base;    /* physical base address of CPIO archive */
    uint64_t       size;    /* total byte size of the archive        */
    int            loaded;  /* non-zero once successfully loaded     */
} initramfs_t;

extern initramfs_t g_initramfs;

/* ── Multiboot2 tag types we care about ─────────────────────────── */
#define MB2_TAG_END     0
#define MB2_TAG_MODULE  3

typedef struct __attribute__((packed)) {
    uint32_t type;
    uint32_t size;
} mb2_tag_hdr_t;

typedef struct __attribute__((packed)) {
    uint32_t type;
    uint32_t size;
    uint32_t mod_start;     /* physical start address (32-bit)      */
    uint32_t mod_end;       /* physical end address   (32-bit)      */
    char     cmdline[];     /* module command line string            */
} mb2_mod_tag_t;

/* ── Public API ──────────────────────────────────────────────────── */

/*
 * initramfs_load – scan Multiboot2 info for a module tag and register
 * the first one as the initramfs CPIO archive.
 *
 * Parameters:
 *   mb2_magic  –  value from rdi (should be 0x36D76289)
 *   mb2_info   –  physical address of the Multiboot2 info structure
 *
 * Returns 1 on success, 0 if no module was found.
 */
static inline int initramfs_load(uint32_t mb2_magic, uint64_t mb2_info_addr)
{
    if (mb2_magic != 0x36D76289u)
        return 0;

    /* The Multiboot2 info structure starts with a total_size uint32,
     * followed by a reserved uint32, then the tag stream. */
    const uint8_t *info = (const uint8_t *)(uintptr_t)mb2_info_addr;
    uint32_t total = *(const uint32_t *)info;

    const uint8_t *p   = info + 8;          /* skip total_size + reserved */
    const uint8_t *end = info + total;

    while (p < end) {
        const mb2_tag_hdr_t *hdr = (const mb2_tag_hdr_t *)p;

        if (hdr->type == MB2_TAG_END)
            break;

        if (hdr->type == MB2_TAG_MODULE) {
            const mb2_mod_tag_t *mod = (const mb2_mod_tag_t *)p;
            g_initramfs.base   = (const uint8_t *)(uintptr_t)mod->mod_start;
            g_initramfs.size   = (uint64_t)(mod->mod_end - mod->mod_start);
            g_initramfs.loaded = 1;
            return 1;
        }

        /* Advance to next tag – each tag is padded to 8-byte alignment */
        uint32_t aligned = (hdr->size + 7u) & ~7u;
        if (aligned == 0) break;   /* safety: avoid infinite loop */
        p += aligned;
    }

    return 0;
}

/* ── Internal helpers ────────────────────────────────────────────── */

/* Parse an 8-character ASCII hex field from a cpio header */
static inline uint32_t _cpio_parse_hex(const char *s)
{
    uint32_t v = 0;
    for (int i = 0; i < 8; i++) {
        char c = s[i];
        v <<= 4;
        if (c >= '0' && c <= '9') v |= (uint32_t)(c - '0');
        else if (c >= 'A' && c <= 'F') v |= (uint32_t)(c - 'A' + 10);
        else if (c >= 'a' && c <= 'f') v |= (uint32_t)(c - 'a' + 10);
    }
    return v;
}

/* Minimal strcmp without libc */
static inline int _cpio_streq(const char *a, const char *b)
{
    while (*a && *b && *a == *b) { a++; b++; }
    return (*a == '\0' && *b == '\0');
}

/* Round up to next 4-byte boundary */
static inline uint32_t _cpio_align4(uint32_t v)
{
    return (v + 3u) & ~3u;
}

/*
 * initramfs_find – locate a file by path inside the CPIO archive.
 *
 * The path may be given with or without a leading "./".
 * Returns a pointer to the file data on success, NULL otherwise.
 * *out_size is set to the file's byte size.
 */
static inline const uint8_t *initramfs_find(const char *path, uint32_t *out_size)
{
    if (!g_initramfs.loaded || !g_initramfs.base)
        return (void *)0;

    const uint8_t *p   = g_initramfs.base;
    const uint8_t *end = g_initramfs.base + g_initramfs.size;

    while (p + CPIO_NEWC_HDR_SIZE <= end) {
        const cpio_newc_hdr_t *hdr = (const cpio_newc_hdr_t *)p;

        /* Validate magic */
        if (hdr->magic[0] != '0' || hdr->magic[1] != '7' ||
            hdr->magic[2] != '0' || hdr->magic[3] != '7' ||
            hdr->magic[4] != '0' ||
            (hdr->magic[5] != '1' && hdr->magic[5] != '2'))
            break;

        uint32_t filesize = _cpio_parse_hex(hdr->filesize);
        uint32_t namesize = _cpio_parse_hex(hdr->namesize);

        /* Name starts immediately after the header */
        const char *name = (const char *)(p + CPIO_NEWC_HDR_SIZE);

        /* Check for end-of-archive sentinel */
        if (namesize >= 11) {
            /* "TRAILER!!!" is 10 chars + NUL = 11 */
            int trailer = 1;
            const char *t = "TRAILER!!!";
            for (int i = 0; i < 10 && trailer; i++)
                if (name[i] != t[i]) trailer = 0;
            if (trailer) break;
        }

        /* Normalise path: skip leading "./" */
        const char *cmp_name = name;
        if (cmp_name[0] == '.' && cmp_name[1] == '/')
            cmp_name += 2;

        /* Also normalise the query path */
        const char *cmp_path = path;
        if (cmp_path[0] == '.' && cmp_path[1] == '/')
            cmp_path += 2;

        if (_cpio_streq(cmp_name, cmp_path)) {
            /* Data follows the name, both padded to 4-byte boundaries */
            uint32_t data_off = _cpio_align4(CPIO_NEWC_HDR_SIZE + namesize);
            if (out_size) *out_size = filesize;
            return p + data_off;
        }

        /* Advance to the next entry */
        uint32_t entry_size = _cpio_align4(CPIO_NEWC_HDR_SIZE + namesize)
                            + _cpio_align4(filesize);
        p += entry_size;
    }

    return (void *)0;
}

/*
 * initramfs_foreach – iterate every regular file in the archive.
 *
 * cb(path, data, size, userdata) is called for each regular file.
 * Directories and the TRAILER are skipped automatically.
 * Iteration stops early if cb returns non-zero.
 */
typedef int (*initramfs_cb_t)(const char *path,
                               const uint8_t *data,
                               uint32_t size,
                               void *userdata);

static inline void initramfs_foreach(initramfs_cb_t cb, void *userdata)
{
    if (!g_initramfs.loaded || !g_initramfs.base || !cb)
        return;

    const uint8_t *p   = g_initramfs.base;
    const uint8_t *end = g_initramfs.base + g_initramfs.size;

    while (p + CPIO_NEWC_HDR_SIZE <= end) {
        const cpio_newc_hdr_t *hdr = (const cpio_newc_hdr_t *)p;

        if (hdr->magic[0] != '0' || hdr->magic[1] != '7' ||
            hdr->magic[2] != '0' || hdr->magic[3] != '7' ||
            hdr->magic[4] != '0' ||
            (hdr->magic[5] != '1' && hdr->magic[5] != '2'))
            break;

        uint32_t filesize = _cpio_parse_hex(hdr->filesize);
        uint32_t namesize = _cpio_parse_hex(hdr->namesize);
        uint32_t mode     = _cpio_parse_hex(hdr->mode);

        const char *name = (const char *)(p + CPIO_NEWC_HDR_SIZE);

        /* Check for TRAILER!!! */
        if (namesize >= 11) {
            int trailer = 1;
            const char *t = "TRAILER!!!";
            for (int i = 0; i < 10 && trailer; i++)
                if (name[i] != t[i]) trailer = 0;
            if (trailer) break;
        }

        uint32_t data_off = _cpio_align4(CPIO_NEWC_HDR_SIZE + namesize);

        /* Only call back for regular files (S_IFREG = 0100000 octal = 0x8000) */
        if ((mode & 0xF000u) == 0x8000u && filesize > 0) {
            const char *cmp = name;
            if (cmp[0] == '.' && cmp[1] == '/') cmp += 2;
            if (cb(cmp, p + data_off, filesize, userdata))
                return;
        }

        uint32_t entry_size = data_off + _cpio_align4(filesize);
        p += entry_size;
    }
}

/*
 * initramfs_list_count – returns the number of regular files in the archive.
 * Useful for boot diagnostics.
 */
static inline int initramfs_list_count(void)
{
    int count = 0;
    /* We use a local lambda-style wrapper via a static helper */
    /* Since C99 has no closures, we count inline */
    if (!g_initramfs.loaded || !g_initramfs.base)
        return 0;

    const uint8_t *p   = g_initramfs.base;
    const uint8_t *end = g_initramfs.base + g_initramfs.size;

    while (p + CPIO_NEWC_HDR_SIZE <= end) {
        const cpio_newc_hdr_t *hdr = (const cpio_newc_hdr_t *)p;

        if (hdr->magic[0] != '0') break;

        uint32_t filesize = _cpio_parse_hex(hdr->filesize);
        uint32_t namesize = _cpio_parse_hex(hdr->namesize);
        uint32_t mode     = _cpio_parse_hex(hdr->mode);

        const char *name = (const char *)(p + CPIO_NEWC_HDR_SIZE);
        if (namesize >= 11) {
            int trailer = 1;
            const char *t = "TRAILER!!!";
            for (int i = 0; i < 10 && trailer; i++)
                if (name[i] != t[i]) trailer = 0;
            if (trailer) break;
        }

        if ((mode & 0xF000u) == 0x8000u) count++;

        uint32_t entry_size = _cpio_align4(CPIO_NEWC_HDR_SIZE + namesize)
                            + _cpio_align4(filesize);
        p += entry_size;
    }

    return count;
}

#endif /* INITRAMFS_H */
